# Funcionarios
Trabalho Para Entregar: Um crud simples vinculado com Banco de dados Utilizando SQL SERVER &amp; SOMEE.COM ,
Aula de Projeto Banco de Dados MVC


#Tela Inicial:
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/c1ab062f-22ad-425c-a5e0-56d09c62e60b)

#BOTÃO PARA AS MINHAS REDES SOCIAIS (TUDO FUNCIONAOD CONFORME AS IMAGENS ABAIXO:

![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/80054c6d-5df6-4786-8506-b143f070004b)

#Linkedin:

![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/87daf262-ea0f-4600-be7d-5e915170f590)
Github:

![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/293ec44b-b470-4fb0-9762-82ba1ad9a2ae)
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/52cd579a-38fc-4afd-a0e6-e89edc073c60)

Telegram:

![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/43f3cfea-b101-4622-ac15-2cd9d3f5979d)
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/2ba96fc4-6716-4516-885f-b2453f4e0f29)



#TELA DE FUNCIONARIOS:

![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/415ff9e7-195b-4f28-af5d-b4a49ffc4279)
*EDITAR
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/e64e5a96-d317-4e6c-a885-56d6bd21100d)
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/4ceca575-bdf7-4e47-a22c-63a31f0b2a95)
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/c722e94f-dfaa-4b69-8279-9e3b222abbee)

#DETALHES:
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/41494791-ecaa-450e-a891-8d22d2bb5351)
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/1c7315f4-4e70-4c38-87d2-089c55eb1fa4)


#DELETE:
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/baa0f33c-1bef-4477-977a-ab44e2c5bda3)

BANCO DE DADOS (SOMEE & SQL SERVER):
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/c1d22845-86d5-49ba-92f6-d51078656981)
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/8392423e-5bbf-4499-a9f6-19df7ae0c24d)
![image](https://github.com/Joaovictoraparecido/Funcionarios/assets/115484907/d2dae475-33b9-412e-93d2-09dd12c1a07f)






